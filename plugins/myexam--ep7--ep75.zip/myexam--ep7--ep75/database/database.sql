-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 26, 2019 at 04:23 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_db_myexam`
--
CREATE DATABASE IF NOT EXISTS `my_db_myexam` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `my_db_myexam`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_answer`
--

CREATE TABLE `tbl_answer` (
  `a_id` int(11) NOT NULL,
  `ref_m_id` int(11) NOT NULL,
  `ref_sub_id` int(11) NOT NULL,
  `ref_q_id` int(11) NOT NULL,
  `a_ans` varchar(1) NOT NULL,
  `a_datesave` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_examiner`
--

CREATE TABLE `tbl_examiner` (
  `e_id` int(11) NOT NULL,
  `ref_m_id` int(11) NOT NULL,
  `ref_sub_id` int(11) NOT NULL,
  `e_datesave` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_level`
--

CREATE TABLE `tbl_level` (
  `lev_id` int(11) NOT NULL,
  `ref_sub_id` int(11) NOT NULL,
  `lev_gain` varchar(10) NOT NULL,
  `lev_description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `m_id` int(11) NOT NULL,
  `ref_pid` int(11) NOT NULL COMMENT 'รหัสตำแหน่ง',
  `m_username` varchar(50) NOT NULL,
  `m_password` varchar(50) NOT NULL,
  `m_fname` varchar(30) NOT NULL,
  `m_name` varchar(100) NOT NULL,
  `m_lname` varchar(100) NOT NULL,
  `m_phone` varchar(15) NOT NULL,
  `m_email` varchar(50) NOT NULL,
  `m_img` varchar(50) NOT NULL,
  `m_datesave` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`m_id`, `ref_pid`, `m_username`, `m_password`, `m_fname`, `m_name`, `m_lname`, `m_phone`, `m_email`, `m_img`, `m_datesave`) VALUES
(1, 1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Mr.', 'Admin', 'test', '09999999', 'admin@test.com', '8fe38ddb0725ca8e99f8bd1afc79cf4c.png', '2019-05-13 04:02:03');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_position`
--

CREATE TABLE `tbl_position` (
  `pid` int(11) NOT NULL,
  `pname` varchar(100) NOT NULL COMMENT 'ชื่อตำแหน่งงาน'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ตำแหน่งงาน';

--
-- Dumping data for table `tbl_position`
--

INSERT INTO `tbl_position` (`pid`, `pname`) VALUES
(1, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_question`
--

CREATE TABLE `tbl_question` (
  `q_id` int(11) NOT NULL,
  `ref_sub_id` int(11) NOT NULL,
  `q_question` varchar(255) NOT NULL,
  `q_a` varchar(200) NOT NULL,
  `q_b` varchar(200) NOT NULL,
  `q_c` varchar(200) NOT NULL,
  `q_d` varchar(200) NOT NULL,
  `q_ans` varchar(1) NOT NULL,
  `q_datesave` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subject`
--

CREATE TABLE `tbl_subject` (
  `sub_id` int(11) NOT NULL,
  `sub_name` varchar(100) NOT NULL,
  `sub_description` text NOT NULL,
  `sub_exam_detail` text NOT NULL,
  `sub_datesave` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_answer`
--
ALTER TABLE `tbl_answer`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `tbl_examiner`
--
ALTER TABLE `tbl_examiner`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `tbl_level`
--
ALTER TABLE `tbl_level`
  ADD PRIMARY KEY (`lev_id`);

--
-- Indexes for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `tbl_position`
--
ALTER TABLE `tbl_position`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `tbl_question`
--
ALTER TABLE `tbl_question`
  ADD PRIMARY KEY (`q_id`);

--
-- Indexes for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  ADD PRIMARY KEY (`sub_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_answer`
--
ALTER TABLE `tbl_answer`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_examiner`
--
ALTER TABLE `tbl_examiner`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_level`
--
ALTER TABLE `tbl_level`
  MODIFY `lev_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_member`
--
ALTER TABLE `tbl_member`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_position`
--
ALTER TABLE `tbl_position`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_question`
--
ALTER TABLE `tbl_question`
  MODIFY `q_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
